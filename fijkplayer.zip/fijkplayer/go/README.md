# fijkplayer

This Go package implements the host-side of the Flutter [fijkplayer](https://github.com/befovy/fijkplayer) plugin.

## Usage

fijkplayer is a hover compatible plugin.

Just run `hover plugins get` to import go code.


## Prebuilt shared library

But take care fijkplayer use a prebuilt shared c library.
The library is not provided default.   
You need to build the library from https://github.com/befovy/ijkplayer

The library is only tested on Mac OS yet.