#!/usr/bin/env bash
#
# Run a local instance of the site.
bundle exec jekyll serve
