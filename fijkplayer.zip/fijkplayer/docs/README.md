# fijkplayer website #

The [fijkplayer website](https://befovy.github.io/fijkplayer/) is hosted on
GitHub Pages, and is statically generated using Jekyll.

* GitHub provides a guide describing how to setup a GitHub Pages site using
  Jekyll
  [here](https://help.github.com/articles/using-jekyll-as-a-static-site-generator-with-github-pages/).
* GitHub provides a guide describing how to test changes to the site locally
  [here](https://help.github.com/articles/setting-up-your-github-pages-site-locally-with-jekyll/).
  Once your machine is setup, you can build and run a local instance of the
  site using `./run_locally.sh` from the root directory.
